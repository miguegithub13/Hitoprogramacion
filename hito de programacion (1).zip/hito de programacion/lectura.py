import xlrd

filepath = "C:\\Users\\Tecnicos\\Desktop\\Nueva carpeta\\hito de programacion\\54598.xlsx"

openfile = xlrd.open_workbook(filepath)

sheet = openfile.sheet_by_name("54598.xlsx")
print('nro de filas',sheet.nrows)
print ('nro de columnas',sheet.ncols)
